let container = document.querySelector("#container");
let message = document.createElement('p');
message.classList.add('popUp');
container.appendChild(message);

let btnWelcome = document.createElement('button');
btnWelcome.innerHTML = "Welcome";
btnWelcome.classList.add('btnwelcome');
container.appendChild(btnWelcome);


let btnreplay = document.createElement('button');
btnreplay.innerHTML = "REPLAY";
btnreplay.classList.add('btnreplay');


let msg = document.createElement('h1');
msg.classList.add('entrer');
container.appendChild(msg);

let gameover = false;

let cupMode = false
let game = [
    ['', '', ''],
    ['', '', ''],
    ['', '', ''],
];

let counter = 0;
let playerOne = "X";
let playerTwo = "O";

function choicePlayer(row, col) {
    if (game[row][col] === "" && !gameover) {
        if (counter % 2 === 0) {
            game[row][col] = playerOne;
            if (cupMode == true) {
                cpu(game)
            }

        } else {
            game[row][col] = playerTwo;
        }
        counter++;
        Winner(game);
        createElement(game)
    }
}

function Winner(table) {
    let winner = null;

    for (let i = 0; i < table.length; i++) {
        if (table[i][0] && table[i][0] === table[i][1] && table[i][0] === table[i][2]) {
            winner = table[i][0];
            break;
        }
    }

    if (!winner) {
        for (let j = 0; j < table[0].length; j++) {
            if (table[0][j] && table[0][j] === table[1][j] && table[0][j] === table[2][j]) {
                winner = table[0][j];
                break;
            }
        }
    }

    if (!winner) {
        if (table[0][0] && table[0][0] === table[1][1] && table[0][0] === table[2][2]) {
            winner = table[0][0];
        } else if (table[0][2] && table[0][2] === table[1][1] && table[0][2] === table[2][0]) {
            winner = table[0][2];
        }
    }

    if (winner) {
        message.innerHTML = `${winner} a gagné`;
        gameover = true;
    } else if (table.flat().every(cell => cell !== '')) {
        message.innerHTML = "Match nul";
        gameover = true;
    } else {
        message.innerHTML = "En cours...";
    }
}

function createElement(table) {
    container.innerHTML = '';
    container.appendChild(message);
    container.appendChild(btnreplay);
    container.appendChild(btncpu);

    let grille = document.createElement('div');
    grille.classList.add('grille');
    container.appendChild(grille);

    table.forEach((row, rowIndex) => {
        let ligne = document.createElement('div');
        ligne.classList.add('ligne');
        row.forEach((boxe, colIndex) => {
            let cellule = document.createElement('div');
            cellule.addEventListener('click', () => {
                choicePlayer(rowIndex, colIndex);
            });
            switch (boxe) {
                case playerOne:
                    cellule.innerHTML = playerOne /* en redessinant la grille le switch réaffiche en html le choix du player one dans la boxe qu'il a choisi auparavant*/
                    break;
                case playerTwo:
                    cellule.innerHTML = playerTwo
                default:
                    break;
            }
            cellule.classList.add('cell');
            ligne.appendChild(cellule);
        });
        grille.appendChild(ligne);
    });
}

function reset(table) {

    table.forEach((row, i) => {
        row.forEach((boxe, j) => {
            table[i][j] = ""
        })
    });

    counter = 0;
    gameover = false;
    message.innerHTML = "Et c'est reparti";
    createElement(table);
}



function start() {
    msg.innerHTML = "Bienvenue au jeu du morpion";

    btnWelcome.addEventListener('click', () => {
        createElement(game);
        btnWelcome.style.display = 'none';
        container.appendChild(btnreplay);
        reset(game)
    });


    btnreplay.addEventListener('click', () => {
        reset(game)
    });
}

start();


function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
 
}




let btncpu = document.createElement('button');
btncpu.innerHTML = "Ordinateur";
btncpu.classList.add('btncpu');



function cpu(table) {
   if (counter < 8) {
    let randomplayerX = random(0, table.length - 1)
    let randomplayerY = random(0, table[0].length - 1)
    while ( game[randomplayerX][randomplayerY] != "") {
        randomplayerX = random(0, table.length - 1)
        randomplayerY = random(0, table[0].length - 1)
    }
    game[randomplayerX][randomplayerY] = playerTwo
    counter++
   }

}


btncpu.addEventListener('click', () => {
    createElement(game);
        btnWelcome.style.display = 'none';
        container.appendChild(btnreplay);
        reset(game)
        cupMode = !cupMode
   
})







/*todo= 

2- crée la version cpu 
3-crée la possibilité de jouer avec le cpu ou à deux  
*/

